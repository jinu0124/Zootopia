import pymysql
import sys
import os
import FinanceDataReader as fdr
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.layers import LSTM
from datetime import datetime, timedelta
from scipy import stats
import OpenDartReader
from marcap import marcap_data

pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)

api_key = '5f7647c213c1aa874a889ff66a791412bc1020b7'
dart = OpenDartReader(api_key)
# pd.set_option('display.max_rows', None)

mysql_db = pymysql.connect(
    user="root",
    passwd="1103",
    host="127.0.0.1",
    port=3308,
    db="stock",
    charset="utf8"
)

def stock(title):

    def make_dataset(data, label, window_size):
        feature_list = []
        label_list = []
        for i in range(len(data) - window_size):
            # f : [0~19], [1~20], [2~21], [3~22], [4~23],
            # l : [20],   [21],   [22],   [23],   [24]
            feature_list.append(np.array(data.iloc[i:i + window_size]))         # WINDOW_SIZE 만큼의 데이터씩 담기
            label_list.append(np.array(label.iloc[i + window_size]))
        return np.array(feature_list), np.array(label_list)

    def make_test_dataset(data, window_size):
        feature_list = []
        for i in range(len(data) - window_size + 1):
            # f : [0~19]
            feature_list.append(np.array(data.iloc[i:i + window_size]))         # WINDOW_SIZE 만큼의 데이터씩 담기
        return np.array(feature_list)


    print(title)
    # name = str(input("종목 입력 : "))

# X 변수 : Change((종가기준)전일 대비 증감), Close - Open(당일 증감), Volumn * Close(총 거래액), Change[-1](전일 증감), Change[-2](이틀 전 증감)
# Y 결과 : Close[+1](익일 종가)

    sql = "SELECT * FROM stock WHERE NAME NOT LIKE '%우' AND sector NOT LIKE 'nan' AND market IN ('KOSPI', 'KOSDAQ')"
    cursor = mysql_db.cursor(pymysql.cursors.DictCursor)
    cursor.execute(sql)
    rows = cursor.fetchall()

    train_features = pd.DataFrame()
    train_labels = pd.DataFrame()
    scale_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
    train_dim0 = 0
    BATCH_SIZE = 16                 # 결과 이상하면 배치사이즈 : 1로 바꿔보기
    test = pd.DataFrame()

    WINDOW_SIZE = 24  # 다음날 예측에 사용할 현재일로부터 ~ 과거 데이터 개수
    FORECAST = 24       # 예측할 날 수

    for i, row in enumerate(rows):
        # 종목 Symbol 가져오기
        name = row['NAME']

        sql = "SELECT * FROM stock_data WHERE symbol LIKE '" + row['symbol'] + "' order by id"
        cursor.execute(sql)
        rows = cursor.fetchall()
        # print(rows)
        cols = ['open', 'high', 'low', 'close', 'volume']
        print(pd.DataFrame(rows)[cols])
        df = pd.DataFrame(rows)[cols]
        df.index = pd.DataFrame(rows)['date']
        print(df)
        print(input("stop : "))

        # prev_day = datetime.date.today() - datetime.timedelta(days=1200)
        #
        # # 해당 종목 번호  ~ 이후 주식 데이터 가져오기 & 정규화
        # print(i, name, row['symbol'])
        # df = fdr.DataReader(row['symbol'], prev_day)
        # if len(df) < 400: continue

        # dfm = marcap_data('2021-07-02', '2021-08-02', code=rows[0]['symbol'])
        # print(dfm['Stocks'][0])
        df_date = df.index.values                                       # 행 이름 추출(날짜 데이터)

        scaler = MinMaxScaler()                                         # 정규화 : 값을 0 ~ 1 로 정규화
        df.sort_index(ascending=False)
        new_df = df[1:-1]
        # for i in range(6):
        #     pearsonr, pval = stats.pearsonr(df.iloc[:-1, i], df['Close'][1:])
        #     print(df.columns[i], " / Close")
        #     print("p 값 :", format(pval, '.5f'), "    피어슨 상관계수 (r) :", format(pearsonr, '.5f'))
        #
        #     pearsonr, pval = stats.pearsonr(df.iloc[:-1, i], df.iloc[1:, i])
        #     print(df.columns[i], df.columns[i])
        #     print("p 값 :", format(pval, '.5f'), "    피어슨 상관계수 (r) :", format(pearsonr, '.5f'))


        # new_df['Abs(Change)'] = abs(new_df['Change'])
        # new_df['High - Low'] = new_df['High'] - new_df['Low']
        # new_df['Abs(Open - Close)'] = abs(new_df['Open'] - new_df['Close'])
        # new_df['Open - Close'] = new_df['Open'] - new_df['Close']
        # new_df['Volume - 1day'] = df['Volume'][:-2].values
        # new_df['Close Diff'] = df['Close'][1:-1].values - df['Close'][0:-2].values
        #
        # new_df['Close Diff + 1day'] = df['Close'][2:].values - df['Close'][1:-1].values
        # new_df['Close + 1day'] = df['Close'][2:].values
        #
        # print(new_df.corr())
        # pearsonr, pval = stats.pearsonr(new_df['Close + 1day'][:].values, new_df['Volume'][:].values)
        # print("p 값 :", format(pval, '.5f'), "    피어슨 상관계수 (r) :", format(pearsonr, '.5f'))
        # print(stats.pearsonr(new_df['Close + 1day'][:].values, new_df['High - Low'][:].values))

        scaler.fit(df[scale_cols])
        df_scaled = scaler.transform(df[scale_cols])
        df_scaled = pd.DataFrame(df_scaled, columns=scale_cols, index=list(df.index.values))

        # df_scaled = pd.DataFrame(df_scaled)
        # df_scaled.columns = scale_cols
        TRAIN_SIZE = round(len(df_scaled) * 1)  # 모델 학습에 사용할 전체 데이터 셋 중 트레이닝 데이터 비율
        train_dim0 += (TRAIN_SIZE - WINDOW_SIZE)

        train = df_scaled[:int(TRAIN_SIZE)]     # 모델 학습에 사용할 데이터 뽑기
        if i == len(rows) - 1:
            test = df_scaled[int(TRAIN_SIZE) - WINDOW_SIZE - FORECAST:]      # 학습된 모델 검증 테스트를 위한 데이터 뽑기
        print(train.shape)
        print(test.shape)

        feature_cols = scale_cols
        label_cols = scale_cols

        train_feature = train[feature_cols]
        train_label = train[label_cols]

        train_feature, train_label = make_dataset(train_feature, train_label, WINDOW_SIZE)
        if i == 0:
            train_features = train_feature
            train_labels = train_label
            continue

        train_features = np.append(train_features, train_feature).reshape(train_dim0, WINDOW_SIZE, 5)
        train_labels = np.append(train_labels, train_label).reshape(train_dim0, 5)
        # train_features = pd.concat([train_features, train_feature])
        # train_labels = pd.concat([train_labels, train_label])
        # train_features += train_feature
        # train_labels += train_label
    print(train_features)
    print("train feature shape : ", train_features.shape)
    print("train label shape : ", train_labels.shape)
    x_train, x_valid, y_train, y_valid = train_test_split(train_features, train_labels, test_size=0.15)
    print(x_train)
    x_train = x_train[:-(len(x_train) % BATCH_SIZE)]
    y_train = y_train[:-(len(y_train) % BATCH_SIZE)]
    x_valid = x_valid[:-(len(x_valid) % BATCH_SIZE)]
    y_valid = y_valid[:-(len(y_valid) % BATCH_SIZE)]
    print(len(x_train))
    print(len(x_valid))
    input("stop : ")

    model = Sequential()
    model.add(LSTM(256,
                   input_shape=(train_features.shape[1], train_features.shape[2]),            # Time Steps, Variables
                   activation='relu',
                   return_sequences=True
                   )
              )
    model.add(LSTM(64, activation='relu', return_sequences=True))
    model.add(LSTM(64, activation='relu', return_sequences=True))
    model.add(LSTM(16, activation='relu', return_sequences=False))
    model.add(Dropout(0.15))
    model.add(Dense(5))
    model.add(Activation('softmax'))         # 결과 이상하면 없애보기

    model.compile(loss='mean_squared_error', optimizer='adam')
    early_stop = EarlyStopping(monitor='val_loss', patience=5)

    model_path = 'model'
    filename = os.path.join(model_path, names[0] + '.h5')
    checkpoint = ModelCheckpoint(filename, monitor='val_loss', verbose=1, save_best_only=True, mode='auto')

    history = model.fit(x_train, y_train,
                        epochs=80,
                        batch_size=BATCH_SIZE,
                        validation_data=(x_valid, y_valid),
                        verbose=1,
                        callbacks=[early_stop, checkpoint])


    test_feature = test[scale_cols]
    # test_label = test[label_cols]

    print("test shape : ", test_feature)
    test_feature = make_test_dataset(test_feature, WINDOW_SIZE)
    print(test_feature.shape)

    model.load_weights(filename)

    for i in range(FORECAST):
        pred = model.predict(test_feature)

        print(test_feature.shape)

        test_feature = test_feature[0][1:]
        # test_feature[WINDOW_SIZE] = pred[0]
        test_feature = np.insert(test_feature, WINDOW_SIZE - 1, pred[0], axis=0)
        test_feature = test_feature.reshape(1, WINDOW_SIZE, 5)

        # test_feature.loc[WINDOW_SIZE] = next
        print("next test set : ", test_feature)
        # test_feature = test_feature[feature_cols]

    print(test_feature[0][: ,3])
    print("================================================")
    print(train_labels[-FORECAST:])
    plot_graph = np.append(train_feature[:, 3], test_feature[0][:, 3])
    plt.plot(train_labels[-FORECAST:, 3], label='actual')
    plt.plot(test_feature[0][:, 3], label='prediction')
    plt.legend()
    plt.show()




    # df['Mid'] = (df['High'] + df['Low']) / 2
    # df['MA5'] = df['Close'].rolling(window=200).mean()
    # df = df.fillna(0)
    #
    # min_max_scaler = MinMaxScaler()
    # min_max_scaler.fit(df)
    # output = pd.DataFrame(min_max_scaler.transform(df), columns=df.columns, index=list(df.index.values))
    # print(output.head())

def save_stock():
    df_krx = fdr.StockListing('KRX')
    df_nas = fdr.StockListing('NASDAQ')

    df_select = df_krx
    sql_dt = "values"
    for i in range(0, len(df_select) - 1):
        if df_select['Name'][i].count('\'') > 0: df_select['Name'][i] = df_select['Name'][i].replace("'", "")
        if str(df_select['Sector'][i]).count('\'') > 0: df_select['Sector'][i] = str(df_select['Sector'][i]).replace(
            "'", "")

        sql_dt += "('" + str(df_select['Symbol'][i]) + "','" + str(df_select['Market'][i]) + "','" + str(
            df_select['Name'][i]) + "','" + \
                  str(df_select['Sector'][i]) + "','" + str(df_select['Region'][i]) + "'),"

    sql_dt += "('" + str(df_select['Symbol'][len(df_select) - 1]) + "','" + str(
        df_select['Market'][len(df_select) - 1]) + "','" + str(df_select['Name'][len(df_select) - 1]) + "','" + \
              str(df_select['Sector'][len(df_select) - 1]) + "','" + str(
        df_select['Region'][len(df_select) - 1]) + "');"

    cursor = mysql_db.cursor(pymysql.cursors.DictCursor)

    sql = "insert into stock(symbol, market, name, sector, region) " + sql_dt
    cursor.execute(sql)
    mysql_db.commit()

    df_nas['Market'] = 'NASDAQ'
    df_nas['Sector'] = df_nas['Industry']
    df_nas['Region'] = 'USA'
    df_select = df_nas

    sql_dt = "values"
    for i in range(0, len(df_select) - 1):
        if df_select['Name'][i].count('\'') > 0: df_select['Name'][i] = df_select['Name'][i].replace("'", "")
        if str(df_select['Sector'][i]).count('\'') > 0: df_select['Sector'][i] = str(df_select['Sector'][i]).replace("'", "")

        sql_dt += "('" + str(df_select['Symbol'][i]) + "','" + str(df_select['Market'][i]) + "','" + str(df_select['Name'][i]) + "','" +\
                  str(df_select['Sector'][i]) + "','" + str(df_select['Region'][i]) + "'),"

    sql_dt += "('" + str(df_select['Symbol'][len(df_select) - 1]) + "','" + str(df_select['Market'][len(df_select) - 1]) + "','" + str(df_select['Name'][len(df_select) - 1]) + "','" + \
              str(df_select['Sector'][len(df_select) - 1]) + "','" + str(df_select['Region'][len(df_select) - 1]) + "');"

    cursor = mysql_db.cursor(pymysql.cursors.DictCursor)

    sql = "insert into stock(symbol, market, name, sector, region) " + sql_dt
    cursor.execute(sql)
    mysql_db.commit()


def save_stock_data():
    sql = "SELECT * FROM stock WHERE NAME NOT LIKE '%우' AND sector NOT LIKE 'nan' AND market IN ('KOSPI', 'KOSDAQ')"
    cursor = mysql_db.cursor(pymysql.cursors.DictCursor)
    cursor.execute(sql)
    rows = cursor.fetchall()

    for i, row in enumerate(rows):
        # 종목 Symbol 가져오기
        name = row['NAME']
        prev_day = datetime.today() - timedelta(days=1200)

        # 해당 종목 번호  ~ 이후 주식 데이터 가져오기 & 정규화
        print(i, name, row['symbol'])
        df = fdr.DataReader(row['symbol'], prev_day)

        print(df.index.values)
        print(df.index.values[0])
        print(np.datetime64(df.index.values[0]).astype(datetime))
        ts = np.datetime64(df.index.values[0]).astype(datetime)/1000000000 ################################
        print(datetime.fromtimestamp(int(ts)))
        print(input("stop : "))
        if(len(df) < 400) : continue
        sql_dt = "values"
        for i in range(0, len(df) - 1):
            sql_dt += "('" + str(df.index.values[i]) + "','" + str(row['symbol']) + "','" + str(df['Open'][i]) + "','" + str(df['High'][i]) + "','" + str(
                df['Low'][i]) + "','" + str(df['Close'][i]) + "','" + str(df['Volume'][i]) + "'),"

        sql_dt += "('" + str(df.index.values[-1]) + "','" + str(row['symbol']) + "','" + str(df['Open'][i]) + "','" + str(df['High'][i]) + "','" + str(
                df['Low'][i]) + "','" + str(df['Close'][i]) + "','" + str(df['Volume'][i]) + "');"

        # print(sql_dt)
        sql = "insert into stock_data(date, symbol, open, high, low, close, volume) " + sql_dt
        cursor.execute(sql)
    mysql_db.commit()

if __name__ == '__main__':
    # stock('stock LSTM prediction')

    # save_stock()

    save_stock_data()



